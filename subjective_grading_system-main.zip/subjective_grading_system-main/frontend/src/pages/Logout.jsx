// src/pages/Logout.jsx

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Logout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Clear any user-related data from local storage or session
    localStorage.removeItem('userToken');
    localStorage.removeItem('userType');

    // Redirect to login page after logging out
    navigate('/login');
  }, [navigate]);

  return (
    <div className="logout-page">
      <h2>Logging Out...</h2>
    </div>
  );
};

export default Logout;
